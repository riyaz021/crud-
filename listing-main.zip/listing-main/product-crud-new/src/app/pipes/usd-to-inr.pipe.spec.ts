import { UsdToInrPipe } from './usd-to-inr.pipe';

describe('UsdToInrPipe', () => {
  it('create an instance', () => {
    const pipe = new UsdToInrPipe();
    expect(pipe).toBeTruthy();
  });
});
